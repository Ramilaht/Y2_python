# Nutrients and Calories calculator

## Checkpoint 6

## Current features

- A functional graphic UI that collects user input and compiles them into goals.
- Food logging in the GUI is not yet completely functional but at the home stretch.
- Loading goals from file in the GUI is also functional.
- Test exist for NutrientGoal and MainWindow classes.

## User instructions

- The program can be run from app.py.
- You should be able to progress until the logged food is supposed to appear in the bottom-right.

## Timetable

- Same as before, I think the project is coming along according to the schedule.
- About 65 hours have been spent so far. Coming up with tests was harder than expected due to the different nature of testing code compared to conventional.

## Other
- I haven't had to alter my original plan, this is quite a simple program when it comes down to it.
- No major problems encountered.