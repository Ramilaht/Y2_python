# Nutrients and Calories calculator

## Checkpoint3

## Current features

- Text-based goal inputs that are asked with "input". 
- Food logging is also functional.
- Loading goals from file somewhat functional.
- Graphic methods:
  - An input window exists.
  - A Result Window is somewhat functional.

## User instructions

- The program is in a running state.
- The program can be run from app.py.

## Timetable

- I have used approximately 40-45 hours at this point.
- There haven't been any major hiccups, I just have a hard time finding bugs sometimes. No major changes to timetable.

## Other
- There haven't been any particular problems, maybe with showing multiple windows in succession but that is it.
- I haven't had to alter my original plan.
