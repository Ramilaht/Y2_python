# Nutrients and calories calculator

## Description

## File and folder format

 - In the documents folder all the documentation (including this) can be found. In the code folder you will find all the code files.

 - All the code found in the folder is my own excluding implementations of PyQt6.


## Installation

- You will need PyQt6 installed. This can be done by inputting "pip install PyQt6" into the terminal.


## User instructions
- The Program can be run from app.py. After that the Program will tell the user what they need to do next.
- There are no settings files or other external files that user will have to worry about.
